import java.util.HashSet;
import java.util.Set;

public class Graph {
    private Set<Vertex> vertices;
    private Set<Edge> edges;

    public Graph() {
        vertices = new HashSet<>();
        edges = new HashSet<>();
    }

    public void addVertex(Vertex vertex) {
        vertices.add(vertex);
    }

    public void addEdge(Vertex vertex1, Vertex vertex2) {
        Edge edge = new Edge(vertex1, vertex2);
        edges.add(edge);
    }

    public Set<Vertex> getVertices() {
        return vertices;
    }

    public Set<Edge> getEdges() {
        return edges;
    }

    public void displayGraph() {
        System.out.println("Vertices:");
        for (Vertex vertex : vertices) {
            System.out.println(vertex);
        }
        System.out.println("\nEdges:");
        for (Edge edge : edges) {
            System.out.println(edge);
        }
    }
}

