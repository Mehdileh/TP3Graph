public class Main {
    public static void main(String[] args) {
        // Création des sommets
        Vertex A = new Vertex("A");
        Vertex B = new Vertex("B");
        Vertex C = new Vertex("C");
        Vertex D = new Vertex("D");

        // Création du graphe
        Graph graph = new Graph();
        graph.addVertex(A);
        graph.addVertex(B);
        graph.addVertex(C);
        graph.addVertex(D);

        // Ajout des arêtes
        graph.addEdge(A, B);
        graph.addEdge(A, C);
        graph.addEdge(B, C);
        graph.addEdge(B, D);

        // Affichage du graphe
        graph.displayGraph();
    }
}
